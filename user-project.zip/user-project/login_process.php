<?php
require_once('config.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validate user credentials (you should hash passwords in a real-world scenario)
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);

        // Generate and store a unique token
        $token = bin2hex(random_bytes(32));
        $_SESSION['user_token'] = $token;

        $updateTokenQuery = "UPDATE users SET token='$token' WHERE id=" . $user['id'];
        mysqli_query($conn, $updateTokenQuery);

        header('Location: dashboard.php');
        exit(); 
    } else {
        echo "Invalid username or password";
    }
}
?>
