<?php
session_start();
require_once('config.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


if (isset($_SESSION['user_token'])) {
    $token = $_SESSION['user_token'];
    $updateTokenQuery = "UPDATE users SET token=NULL WHERE token='$token'";
    mysqli_query($conn, $updateTokenQuery);
}

session_unset();
session_destroy();

header('Location: login.php');
exit();
?>
