<?php 
// header("Access-Control-Allow-Origin: *");
// header("Access-Control-Allow-Methods: GET");
require_once('config.php');
$clientIp=$_GET['client_ip'];
    
if($clientIp!=''){

    $users=$db->execute("select COUNT(ip_address) as ip_count from ip_checklist WHERE ip_address='$clientIp'");
    $ipResult=mysqli_fetch_array($users);
    
    if($ipResult['ip_count']>3){
        echo "IP Black Listed: This IP Address requested the data more than 3 times";
    }else{

        $userList=$db->execute("SELECT username from users");
        while($userResult=mysqli_fetch_array($userList)){
            echo $userResult['username'].'<br>';
        }

        $insertIp=$db->execute("INSERT INTO ip_checklist(ip_address)VALUES('$clientIp')");
    }

}else{
    http_response_code(403);
    header("Status: 403 Forbidden");    

?>

        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>403 Forbidden</title>
        </head>
        <body>
            <h1>403 Forbidden</h1>
            <p>Direct Access to this resource is forbidden.</p>
        </body>
        </html>

<?php } ?>