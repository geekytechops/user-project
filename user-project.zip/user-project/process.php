<?php
require_once('config.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function isIPBlacklisted($ip, $conn) {
    $ip = mysqli_real_escape_string($conn, $ip);
    $result = $conn->query("SELECT * FROM ip_blacklist WHERE ip_address = '$ip'");
    return $result->num_rows > 0;
}

$user_ip = $_SERVER['REMOTE_ADDR'];

if (isIPBlacklisted($user_ip, $conn)) {
    die("Access denied. Your IP address is blacklisted.");
}

$time_limit = time() - 60; // 60 seconds
$result = $conn->query("SELECT COUNT(*) AS count FROM requests WHERE ip_address = '$user_ip' AND timestamp > FROM_UNIXTIME($time_limit)");
$row = $result->fetch_assoc();

if ($row['count'] >= 3) {
    die("Access denied. Too many requests from your IP address.");
}

$input_data = mysqli_real_escape_string($conn, $_POST['inputData']);
$conn->query("INSERT INTO requests (ip_address, data) VALUES ('$user_ip', '$input_data')");

echo "Request processed successfully.";

$conn->close();
?>
