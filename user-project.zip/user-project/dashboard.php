<?php
require_once('config.php');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

session_start();

if (!isset($_SESSION['user_token'])) {
    header('Location: login.php');
    exit();
}

$token = $_SESSION['user_token'];
$query = "SELECT * FROM users WHERE token='$token'";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) == 1) {
    $user = mysqli_fetch_assoc($result);
} else {
    
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
    <h1>Welcome, <?php echo $user['username']; ?>!</h1>
    <a href="logout.php">Logout</a>
</body>
</html>
